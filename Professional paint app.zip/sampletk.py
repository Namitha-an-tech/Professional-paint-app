import tkinter as tk
from tkinter import ttk, colorchooser, simpledialog

class ProfessionalPaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Professional Paint App")
        self.root.geometry("900x600")
        self.pen_color = "black"
        self.brush_size = tk.IntVar(value=2)
        self.tool = tk.StringVar(value="line")
        self.start_x = None
        self.start_y = None

        
        self.create_toolbar()
        self.create_canvas()
        self.create_statusbar()

       
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

    def create_toolbar(self):
        toolbar = ttk.Frame(self.root, padding=5)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        
        ttk.Label(toolbar, text="Tool:").pack(side=tk.LEFT, padx=(0, 5))
        tools = ["line", "rectangle", "square", "circle", "triangle", "text"]
        self.tool_menu = ttk.Combobox(toolbar, textvariable=self.tool, values=tools, state="readonly", width=12)
        self.tool_menu.pack(side=tk.LEFT, padx=(0, 10))

        
        ttk.Label(toolbar, text="Brush Size:").pack(side=tk.LEFT)
        size_scale = ttk.Scale(toolbar, from_=1, to=10, variable=self.brush_size, orient=tk.HORIZONTAL, length=100)
        size_scale.pack(side=tk.LEFT, padx=(5, 10))

      
        ttk.Button(toolbar, text="Choose Color", command=self.choose_color).pack(side=tk.LEFT, padx=5)

        
        ttk.Button(toolbar, text="Clear Canvas", command=self.clear_canvas).pack(side=tk.LEFT, padx=5)

    def create_canvas(self):
        self.canvas = tk.Canvas(self.root, bg="white", bd=2, relief=tk.SUNKEN)
        self.canvas.pack(fill=tk.BOTH, expand=True)

    def create_statusbar(self):
        self.status = tk.StringVar()
        self.status.set("Welcome to Professional Paint App")
        status_bar = ttk.Label(self.root, textvariable=self.status, relief=tk.SUNKEN, anchor="w", padding=2)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    
    def choose_color(self):
        color = colorchooser.askcolor(title="Pick a color")[1]
        if color:
            self.pen_color = color
            self.status.set(f"Color selected: {self.pen_color}")

    def clear_canvas(self):
        self.canvas.delete("all")
        self.status.set("Canvas cleared.")

    def on_click(self, event):
        self.start_x, self.start_y = event.x, event.y
        self.status.set(f"{self.tool.get().capitalize()} tool selected at ({event.x}, {event.y})")

        if self.tool.get() == "text":
            text = simpledialog.askstring("Text Input", "Enter your text:")
            if text:
                self.canvas.create_text(event.x, event.y, text=text, fill=self.pen_color,
                                        font=("Segoe UI", self.brush_size.get() * 3))

    def on_drag(self, event):
        if self.tool.get() == "line":
            self.canvas.create_line(self.start_x, self.start_y, event.x, event.y,
                                    fill=self.pen_color, width=self.brush_size.get(), capstyle=tk.ROUND)
            self.start_x, self.start_y = event.x, event.y

    def on_release(self, event):
        tool = self.tool.get()
        x1, y1, x2, y2 = self.start_x, self.start_y, event.x, event.y

        if tool == "rectangle":
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.pen_color, width=self.brush_size.get())
        elif tool == "square":
            side = min(abs(x2 - x1), abs(y2 - y1))
            x2 = x1 + side if x2 > x1 else x1 - side
            y2 = y1 + side if y2 > y1 else y1 - side
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=self.pen_color, width=self.brush_size.get())
        elif tool == "circle":
            self.canvas.create_oval(x1, y1, x2, y2, outline=self.pen_color, width=self.brush_size.get())
        elif tool == "triangle":
            x3 = x1 + (x2 - x1) / 2
            self.canvas.create_polygon(x1, y2, x2, y2, x3, y1, outline=self.pen_color,
                                       fill='', width=self.brush_size.get())


if __name__ == "__main__":
    root = tk.Tk()
    app = ProfessionalPaintApp(root)
    root.mainloop()

